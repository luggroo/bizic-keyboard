location.replace('../'+location.search+'#grammar/north/104')
